var searchData=
[
  ['floor_5fmax',['FLOOR_MAX',['../cliff_sensor_8h.html#a62d35768cb25b24d2a9e16fe87b8e431',1,'cliffSensor.h']]],
  ['floor_5fmin',['FLOOR_MIN',['../cliff_sensor_8h.html#a19fac6d9ad7a3772c34226466bf79c28',1,'cliffSensor.h']]]
];
