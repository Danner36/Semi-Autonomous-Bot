var searchData=
[
  ['scan',['scan',['../scanner_8c.html#a047344685c73aae3707ffbd91c176a4b',1,'scan():&#160;scanner.c'],['../scanner_8h.html#a047344685c73aae3707ffbd91c176a4b',1,'scan():&#160;scanner.c']]],
  ['send_5fpulse',['send_pulse',['../sonar_8c.html#ace353e57925111137929ec1b9635bd1b',1,'send_pulse():&#160;sonar.c'],['../sonar_8h.html#a6ee4cad698c9131781dc15982a480fbf',1,'send_pulse(void):&#160;sonar.c']]],
  ['senddata',['sendData',['../scanner_8c.html#adb3f832890bac19a930cad550c16ee70',1,'sendData(int i, float distance, float linearWidth):&#160;scanner.c'],['../scanner_8h.html#adb3f832890bac19a930cad550c16ee70',1,'sendData(int i, float distance, float linearWidth):&#160;scanner.c']]],
  ['stop',['stop',['../movement_8c.html#a8c528baf37154d347366083f0f816846',1,'stop():&#160;movement.c'],['../movement_8h.html#a8c528baf37154d347366083f0f816846',1,'stop():&#160;movement.c']]]
];
