var searchData=
[
  ['getdegrees',['getDegrees',['../open__interface_8c.html#a06111b7bdb73f95e0d51d4656beb7c6e',1,'getDegrees(oi_t *self):&#160;open_interface.c'],['../open__interface_8h.html#a06111b7bdb73f95e0d51d4656beb7c6e',1,'getDegrees(oi_t *self):&#160;open_interface.c']]],
  ['getirtodis',['getIRtoDis',['../scanner_8c.html#a68d6c81f89cbec555c363148924c8c47',1,'getIRtoDis(float result):&#160;scanner.c'],['../scanner_8h.html#a68d6c81f89cbec555c363148924c8c47',1,'getIRtoDis(float result):&#160;scanner.c']]],
  ['go_5fcharge',['go_charge',['../open__interface_8c.html#a6c701c5d6642b0f7128b03542a09ed76',1,'go_charge(void):&#160;open_interface.c'],['../open__interface_8h.html#a6c701c5d6642b0f7128b03542a09ed76',1,'go_charge(void):&#160;open_interface.c']]],
  ['gpiof_5fhandler',['GPIOF_Handler',['../open__interface_8c.html#a02aad0ed1a15a7938e39823becf866e6',1,'GPIOF_Handler(void):&#160;open_interface.c'],['../open__interface_8h.html#a02aad0ed1a15a7938e39823becf866e6',1,'GPIOF_Handler(void):&#160;open_interface.c']]]
];
