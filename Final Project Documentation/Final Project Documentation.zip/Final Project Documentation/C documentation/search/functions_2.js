var searchData=
[
  ['calculatelinearwidth',['calculateLinearWidth',['../scanner_8c.html#a6b38cf0ae796899ae3978e8b282645a8',1,'calculateLinearWidth(int angle, float distance):&#160;scanner.c'],['../scanner_8h.html#a6b38cf0ae796899ae3978e8b282645a8',1,'calculateLinearWidth(int angle, float distance):&#160;scanner.c']]],
  ['checkall',['checkAll',['../movement_8c.html#aa06258f6cc05fdbf282f22705b42f124',1,'checkAll(oi_t *sensor):&#160;movement.c'],['../movement_8h.html#a8002b371f97818453740a3670433c69c',1,'checkAll():&#160;movement.h']]],
  ['checkanycliff',['checkAnyCliff',['../cliff_sensor_8c.html#a2e95baa34a20ddd2357498223ba7dd06',1,'checkAnyCliff(oi_t *sensor_data):&#160;cliffSensor.c'],['../cliff_sensor_8h.html#a2e95baa34a20ddd2357498223ba7dd06',1,'checkAnyCliff(oi_t *sensor_data):&#160;cliffSensor.c']]],
  ['checkboundary',['checkBoundary',['../cliff_sensor_8c.html#a488d697eeba45a3940312d3aee465994',1,'checkBoundary(oi_t *sensor_data):&#160;cliffSensor.c'],['../cliff_sensor_8h.html#a488d697eeba45a3940312d3aee465994',1,'checkBoundary(oi_t *sensor_data):&#160;cliffSensor.c']]],
  ['collectdata',['collectData',['../scanner_8c.html#ad4ff4b53ad86a2401a1bd44a82a3cd0e',1,'collectData():&#160;scanner.c'],['../scanner_8h.html#ad4ff4b53ad86a2401a1bd44a82a3cd0e',1,'collectData():&#160;scanner.c']]],
  ['controller_5finput',['controller_input',['../control_8c.html#aabd24f2b93eb9af1fb2b254716a69920',1,'controller_input(unsigned char input, oi_t *sensor):&#160;control.c'],['../control_8h.html#aabd24f2b93eb9af1fb2b254716a69920',1,'controller_input(unsigned char input, oi_t *sensor):&#160;control.c']]]
];
