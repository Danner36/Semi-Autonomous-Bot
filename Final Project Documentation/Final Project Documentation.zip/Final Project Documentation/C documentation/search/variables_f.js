var searchData=
[
  ['totalangle',['totalAngle',['../scanner_8c.html#a8a4bf15c8d390b6b40dc65caf7a5f01c',1,'scanner.c']]],
  ['totaldis',['totalDis',['../scanner_8c.html#a576248b65843b0f76ec0d3ba1a97587d',1,'scanner.c']]]
];
