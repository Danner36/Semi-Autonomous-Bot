var searchData=
[
  ['infraredcharleft',['infraredCharLeft',['../structoi__t.html#ad76a3ef8c00fe4fb26d42e21ed4a1b97',1,'oi_t']]],
  ['infraredcharomni',['infraredCharOmni',['../structoi__t.html#a23f6662c79e9b13336ed5d97adf2f97b',1,'oi_t']]],
  ['infraredcharright',['infraredCharRight',['../structoi__t.html#a4b2d61b83183c40bfd1d569bef4996b7',1,'oi_t']]],
  ['irdis',['irDis',['../scanner_8c.html#ad9b241703b3c919140338da461007549',1,'scanner.c']]]
];
