var searchData=
[
  ['batterycapacity',['batteryCapacity',['../structoi__t.html#a6c31f8965f8949918c5eaf0d1bc17be0',1,'oi_t']]],
  ['batterycharge',['batteryCharge',['../structoi__t.html#a59d673457b0f4a86be6d9a2e251994d8',1,'oi_t']]],
  ['batterycurrent',['batteryCurrent',['../structoi__t.html#a7f441cdd462ae2c8ea161e4f70ecc30e',1,'oi_t']]],
  ['batterytemperature',['batteryTemperature',['../structoi__t.html#aba3741485fbda69cadc30882c38d6fd8',1,'oi_t']]],
  ['batteryvoltage',['batteryVoltage',['../structoi__t.html#a2db6c9307ca3110690cdb512313d7891',1,'oi_t']]],
  ['bumpleft',['bumpLeft',['../structoi__t.html#a824c4a5e7b30099216a347d69a005609',1,'oi_t']]],
  ['bumpright',['bumpRight',['../structoi__t.html#ab9925fb04fac6873cb9b67f8471aa50d',1,'oi_t']]],
  ['buttonclean',['buttonClean',['../structoi__t.html#a6f378668473a5cc4eb3ff21211f12df3',1,'oi_t']]],
  ['buttonclock',['buttonClock',['../structoi__t.html#a42138eef3702b90590423ee2d728faa4',1,'oi_t']]],
  ['buttonday',['buttonDay',['../structoi__t.html#a5280f5d3fe62e2e77951e40c7a92db71',1,'oi_t']]],
  ['buttondock',['buttonDock',['../structoi__t.html#a88054d3e0cdc55c5b9a7298bec41a13d',1,'oi_t']]],
  ['buttonhour',['buttonHour',['../structoi__t.html#a8415545db085823163e91bfb4bd5cb03',1,'oi_t']]],
  ['buttonminute',['buttonMinute',['../structoi__t.html#a6101a4054af0886a74e816282a545e46',1,'oi_t']]],
  ['buttonschedule',['buttonSchedule',['../structoi__t.html#a4025e6af4bd31c26feffac4237c87c45',1,'oi_t']]],
  ['buttonspot',['buttonSpot',['../structoi__t.html#a4cda2dc8b4b56dcea6c994362d211f85',1,'oi_t']]]
];
