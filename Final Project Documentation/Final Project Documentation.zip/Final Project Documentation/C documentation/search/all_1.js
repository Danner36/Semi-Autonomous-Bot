var searchData=
[
  ['adc_2ec',['adc.c',['../adc_8c.html',1,'']]],
  ['adc_2eh',['adc.h',['../adc_8h.html',1,'']]],
  ['adc_5finit',['adc_init',['../adc_8c.html#a1e942fcd91f79d49e4ddb8d7e9d3ef95',1,'adc_init():&#160;adc.c'],['../adc_8h.html#a1e942fcd91f79d49e4ddb8d7e9d3ef95',1,'adc_init():&#160;adc.c']]],
  ['adc_5fread',['adc_Read',['../adc_8c.html#a05557f1389d6a5b022a69c58e361aef9',1,'adc_Read():&#160;adc.c'],['../adc_8h.html#a05557f1389d6a5b022a69c58e361aef9',1,'adc_Read():&#160;adc.c']]],
  ['angle',['angle',['../structoi__t.html#a0674cf41ba25ce1925233d55ea692994',1,'oi_t']]],
  ['angle1',['angle1',['../scanner_8c.html#ae8ff075f9d69d1814ff6a150412b2a13',1,'scanner.c']]],
  ['angle2',['angle2',['../scanner_8c.html#a818372210c0313f380788f4f2e446062',1,'scanner.c']]]
];
