var searchData=
[
  ['main',['main',['../main_8c.html#acdef7a1fd863a6d3770c1268cb06add3',1,'main.c']]],
  ['move_5fbackward',['move_backward',['../movement_8c.html#a0e67b2710d3ee685b2d2bf97625b467b',1,'move_backward(oi_t *sensor, int centimeters, int spd):&#160;movement.c'],['../movement_8h.html#ae7a00fc2da07c0ec67e857b4837880ad',1,'move_backward(oi_t *sensor, int centimeters, int speed):&#160;movement.c']]],
  ['move_5fforward',['move_forward',['../movement_8c.html#ab31acc3361864e7204c07361ce0d452d',1,'move_forward(oi_t *sensor, int centimeters, int spd):&#160;movement.c'],['../movement_8h.html#ac680dc94ab37e43f9f64389b5467946a',1,'move_forward(oi_t *sensor, int centimeters, int speed):&#160;movement.c']]],
  ['move_5fservo',['move_servo',['../servo_8c.html#a9ff7e7778f2d97b408066b15f9b7840a',1,'move_servo(int pulse):&#160;servo.c'],['../servo_8h.html#aa4e220ebe820424b91aa7de9dc501d1b',1,'move_servo(int pulse_period):&#160;servo.c']]]
];
