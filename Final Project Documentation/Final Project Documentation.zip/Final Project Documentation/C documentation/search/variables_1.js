var searchData=
[
  ['angle',['angle',['../structoi__t.html#a0674cf41ba25ce1925233d55ea692994',1,'oi_t']]],
  ['angle1',['angle1',['../scanner_8c.html#ae8ff075f9d69d1814ff6a150412b2a13',1,'scanner.c']]],
  ['angle2',['angle2',['../scanner_8c.html#a818372210c0313f380788f4f2e446062',1,'scanner.c']]]
];
