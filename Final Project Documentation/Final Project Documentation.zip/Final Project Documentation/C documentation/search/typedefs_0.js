var searchData=
[
  ['clock_5ft',['clock_t',['../timer_8h.html#a610f1e1fc118483c18490db0985ebd14',1,'timer.h']]]
];
