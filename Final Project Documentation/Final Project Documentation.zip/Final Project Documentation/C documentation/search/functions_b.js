var searchData=
[
  ['timer3b_5fhandler',['TIMER3B_Handler',['../sonar_8c.html#a0169bae47cb00f30dc5936d788438802',1,'TIMER3B_Handler(void):&#160;sonar.c'],['../sonar_8h.html#a0169bae47cb00f30dc5936d788438802',1,'TIMER3B_Handler(void):&#160;sonar.c']]],
  ['timer_5fgetclock',['timer_getClock',['../timer_8c.html#ab132d5e330af878718aa25f238afb3c5',1,'timer_getClock(void):&#160;timer.c'],['../timer_8h.html#ab132d5e330af878718aa25f238afb3c5',1,'timer_getClock(void):&#160;timer.c']]],
  ['timer_5fstartclock',['timer_startClock',['../timer_8c.html#a43a678f95810bcc411845f6335ac533c',1,'timer_startClock(void):&#160;timer.c'],['../timer_8h.html#a43a678f95810bcc411845f6335ac533c',1,'timer_startClock(void):&#160;timer.c']]],
  ['timer_5fstarttimer',['timer_startTimer',['../timer_8c.html#aa08f6f11a09e2494422193bf0f684614',1,'timer_startTimer(uint16_t startValue):&#160;timer.c'],['../timer_8h.html#aa08f6f11a09e2494422193bf0f684614',1,'timer_startTimer(uint16_t startValue):&#160;timer.c']]],
  ['timer_5fstopclock',['timer_stopClock',['../timer_8c.html#a599f7a15d9067ffb8f32bf0a307e7274',1,'timer_stopClock(void):&#160;timer.c'],['../timer_8h.html#a599f7a15d9067ffb8f32bf0a307e7274',1,'timer_stopClock(void):&#160;timer.c']]],
  ['timer_5fstoptimer',['timer_stopTimer',['../timer_8c.html#a3d897081503b0a7d6d9effeaa463c2b5',1,'timer_stopTimer(void):&#160;timer.c'],['../timer_8h.html#a3d897081503b0a7d6d9effeaa463c2b5',1,'timer_stopTimer(void):&#160;timer.c']]],
  ['timer_5fwaitmicros',['timer_waitMicros',['../timer_8c.html#abcd5da687b304e2354ddb88b72cde64a',1,'timer_waitMicros(uint16_t micros):&#160;timer.c'],['../timer_8h.html#abcd5da687b304e2354ddb88b72cde64a',1,'timer_waitMicros(uint16_t micros):&#160;timer.c']]],
  ['timer_5fwaitmillis',['timer_waitMillis',['../timer_8c.html#a7e2a3b4520e885e5e7d40fa87e242a75',1,'timer_waitMillis(uint32_t millis):&#160;timer.c'],['../timer_8h.html#a7e2a3b4520e885e5e7d40fa87e242a75',1,'timer_waitMillis(uint32_t millis):&#160;timer.c']]],
  ['turn_5fccw',['turn_ccw',['../movement_8c.html#aca14938d98162783dcbe61ac07dbccea',1,'turn_ccw(oi_t *sensor, int degrees, int speed):&#160;movement.c'],['../movement_8h.html#aca14938d98162783dcbe61ac07dbccea',1,'turn_ccw(oi_t *sensor, int degrees, int speed):&#160;movement.c']]],
  ['turn_5fcw',['turn_cw',['../movement_8c.html#a64b7d679749cb6c2f59c5f354e65cd3b',1,'turn_cw(oi_t *sensor, int degrees, int speed):&#160;movement.c'],['../movement_8h.html#a64b7d679749cb6c2f59c5f354e65cd3b',1,'turn_cw(oi_t *sensor, int degrees, int speed):&#160;movement.c']]]
];
