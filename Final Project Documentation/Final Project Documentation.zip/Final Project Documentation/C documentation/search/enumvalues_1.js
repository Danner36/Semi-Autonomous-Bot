var searchData=
[
  ['detected',['DETECTED',['../scanner_8c.html#a015eb90e0de9f16e87bd149d4b9ce959ad3560fe9fd615b5d3177bb08444bbe91',1,'scanner.c']]]
];
