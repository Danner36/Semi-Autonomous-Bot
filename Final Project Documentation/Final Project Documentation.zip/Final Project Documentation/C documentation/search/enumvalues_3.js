var searchData=
[
  ['none',['NONE',['../scanner_8c.html#a015eb90e0de9f16e87bd149d4b9ce959ac157bdf0b85a40d2619cbc8bc1ae5fe2',1,'scanner.c']]]
];
