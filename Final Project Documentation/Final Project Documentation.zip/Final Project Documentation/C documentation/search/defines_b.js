var searchData=
[
  ['sensor_5fpacket_5fsize',['SENSOR_PACKET_SIZE',['../open__interface_8c.html#a0b7617e96cc05d5d1bc29011f3ed9498',1,'open_interface.c']]],
  ['spd_5f1',['SPD_1',['../movement_8h.html#a8a6b26ba3f95ecbd05343c46da0edd8a',1,'movement.h']]],
  ['spd_5f2',['SPD_2',['../movement_8h.html#a9a75e1ac3f8901d6e92a8b05d4095d9f',1,'movement.h']]],
  ['spd_5f3',['SPD_3',['../movement_8h.html#a5d625b389833308e5a1a8c7b6a8293e8',1,'movement.h']]],
  ['spd_5f4',['SPD_4',['../movement_8h.html#a289684124c3123bdb10d5380cc877787',1,'movement.h']]],
  ['spd_5f5',['SPD_5',['../movement_8h.html#ac1c96eb3e65576e7886bffa2ea676fa3',1,'movement.h']]],
  ['spd_5f6',['SPD_6',['../movement_8h.html#aa90550d323a245d447754eb6df418fbd',1,'movement.h']]]
];
