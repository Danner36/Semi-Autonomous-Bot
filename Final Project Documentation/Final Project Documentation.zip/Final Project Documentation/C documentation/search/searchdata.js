var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw",
  1: "o",
  2: "acilmostuw",
  3: "_acgilmoprstuw",
  4: "_abcdfgilmnoprstvw",
  5: "c",
  6: "s",
  7: "cdfnrs",
  8: "bcdefhlmoprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

