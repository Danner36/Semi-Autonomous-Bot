var searchData=
[
  ['mainbrushmotorcurrent',['mainBrushMotorCurrent',['../structoi__t.html#ad3b8a9c6d98b1b2538d8f61ce1d53bf0',1,'oi_t']]]
];
