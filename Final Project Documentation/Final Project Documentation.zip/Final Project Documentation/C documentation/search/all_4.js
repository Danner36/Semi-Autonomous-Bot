var searchData=
[
  ['degree',['DEGREE',['../servo_8h.html#a5d88b17d70c985f2f2b8e987037fd6dd',1,'servo.h']]],
  ['detected',['DETECTED',['../scanner_8c.html#a015eb90e0de9f16e87bd149d4b9ce959ad3560fe9fd615b5d3177bb08444bbe91',1,'scanner.c']]],
  ['difference',['difference',['../sonar_8c.html#aa5dc689211a51245e59b19532ccb207b',1,'sonar.c']]],
  ['dirtdetect',['dirtDetect',['../structoi__t.html#a310417ceded1fa52242eed13b65ac87d',1,'oi_t']]],
  ['distance',['distance',['../structoi__t.html#ad38131f92527ab4d4f780011f74c9d34',1,'oi_t']]]
];
