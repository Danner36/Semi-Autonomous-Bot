var searchData=
[
  ['calib',['CALIB',['../scanner_8c.html#a6536ddf58e8eb4c48d4bb2aaa5d1f122',1,'scanner.c']]],
  ['calib_5fa',['CALIB_A',['../control_8c.html#a10ffa751c5648023a860b0391917df6f',1,'control.c']]],
  ['calib_5fl',['CALIB_L',['../movement_8c.html#a7f3d1b1ce9ab60deddc82897e4c29817',1,'movement.c']]],
  ['calib_5fm',['CALIB_M',['../control_8c.html#a4b2d6b925965cdbba47ad89a24f576b6',1,'control.c']]],
  ['calib_5fr',['CALIB_R',['../movement_8c.html#a92b4107a99eb6d774df2c412701cbad4',1,'movement.c']]],
  ['ccw',['CCW',['../servo_8h.html#a8a460b6555077a64fc97f2e7ef47b843',1,'servo.h']]],
  ['ccw_5f135',['CCW_135',['../servo_8h.html#a36bf3d5a6545f4f9dcd05cc66ff64b62',1,'servo.h']]],
  ['command_5fpin',['COMMAND_PIN',['../wifi_8c.html#aa279f92363521c82491f943828de2711',1,'wifi.c']]],
  ['command_5fstart',['COMMAND_START',['../wifi_8c.html#a6547da940a1c63d92d200f92f5509884',1,'wifi.c']]],
  ['command_5fstop',['COMMAND_STOP',['../wifi_8c.html#a6b66389416f72046f80d9c2c1a77d63f',1,'wifi.c']]],
  ['cw',['CW',['../servo_8h.html#abe61b07c31c2a3e90576eb4c5d95b024',1,'servo.h']]],
  ['cw_5f45',['CW_45',['../servo_8h.html#a2eee3a77285888f3527bf452eec1053f',1,'servo.h']]]
];
