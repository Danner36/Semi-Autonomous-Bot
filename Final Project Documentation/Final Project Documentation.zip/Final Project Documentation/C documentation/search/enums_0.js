var searchData=
[
  ['status',['status',['../scanner_8c.html#a015eb90e0de9f16e87bd149d4b9ce959',1,'scanner.c']]]
];
