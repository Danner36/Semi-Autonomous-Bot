var searchData=
[
  ['sidebrushmotorcurrent',['sideBrushMotorCurrent',['../structoi__t.html#a302a7fc127908e4ad96b4e09e2de3276',1,'oi_t']]],
  ['sonardis',['sonarDis',['../scanner_8c.html#a6ca94591f9d5d1f41b982361a3d72ade',1,'scanner.c']]],
  ['songnumber',['songNumber',['../structoi__t.html#aa271c7f6d456ae134dedb897e92cfaa1',1,'oi_t']]],
  ['songplaying',['songPlaying',['../structoi__t.html#ad2c50dcc11b35661eb477cba53978b7f',1,'oi_t']]],
  ['stasis',['stasis',['../structoi__t.html#ab93e5a43bd4a946cc9749d28995a0822',1,'oi_t']]],
  ['state',['STATE',['../scanner_8c.html#a5ef2a43761c2339b2654df1fad32e2b3',1,'scanner.c']]]
];
