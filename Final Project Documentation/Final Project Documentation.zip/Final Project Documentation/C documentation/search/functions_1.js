var searchData=
[
  ['adc_5finit',['adc_init',['../adc_8c.html#a1e942fcd91f79d49e4ddb8d7e9d3ef95',1,'adc_init():&#160;adc.c'],['../adc_8h.html#a1e942fcd91f79d49e4ddb8d7e9d3ef95',1,'adc_init():&#160;adc.c']]],
  ['adc_5fread',['adc_Read',['../adc_8c.html#a05557f1389d6a5b022a69c58e361aef9',1,'adc_Read():&#160;adc.c'],['../adc_8h.html#a05557f1389d6a5b022a69c58e361aef9',1,'adc_Read():&#160;adc.c']]]
];
