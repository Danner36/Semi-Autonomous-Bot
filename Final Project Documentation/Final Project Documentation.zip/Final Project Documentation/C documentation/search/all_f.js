var searchData=
[
  ['requestedleftvelocity',['requestedLeftVelocity',['../structoi__t.html#a7af2afbb4e2bef0f4c827ff42ae8f84b',1,'oi_t']]],
  ['requestedradius',['requestedRadius',['../structoi__t.html#a41f65336fa0074d0f38f0be533537d8e',1,'oi_t']]],
  ['requestedrightvelocity',['requestedRightVelocity',['../structoi__t.html#ac5518a7ded7e68024213a45fe4218b0a',1,'oi_t']]],
  ['requestedvelocity',['requestedVelocity',['../structoi__t.html#a74edc9cd5f06ae5a987ed77fc5803a5f',1,'oi_t']]],
  ['reset',['reset',['../scanner_8c.html#ad20897c5c8bd47f5d4005989bead0e55',1,'reset():&#160;scanner.c'],['../scanner_8h.html#ad20897c5c8bd47f5d4005989bead0e55',1,'reset():&#160;scanner.c']]],
  ['resetisr',['ResetISR',['../tm4c123gh6pm__startup__ccs_8c.html#a516ff8924be921fa3a1bb7754b1f5734',1,'tm4c123gh6pm_startup_ccs.c']]],
  ['resettempvars',['resetTempVars',['../scanner_8c.html#a66f6fb8c1ee3bcacc7e0c5b602bcee3d',1,'resetTempVars():&#160;scanner.c'],['../scanner_8h.html#a66f6fb8c1ee3bcacc7e0c5b602bcee3d',1,'resetTempVars():&#160;scanner.c']]],
  ['retval_5fsuccess',['RETVAL_SUCCESS',['../wifi_8c.html#ad0e70a4af233cd6fc0c4392f343f99ed',1,'wifi.c']]],
  ['rightencodercount',['rightEncoderCount',['../structoi__t.html#a77fecbd59c3febff1d5b3447a583585e',1,'oi_t']]],
  ['rightmotorcurrent',['rightMotorCurrent',['../structoi__t.html#a9966cc50857bb8736c074353a07ad710',1,'oi_t']]],
  ['rising_5fedge',['Rising_Edge',['../sonar_8c.html#a06fc87d81c62e9abb8790b6e5713c55baa89f612fd3dc2f79633b2a8a13f9c31a',1,'sonar.c']]],
  ['rising_5ftime',['rising_time',['../sonar_8c.html#a2a3ff45a2491cb2efc1c4433e743cd89',1,'sonar.c']]],
  ['rs_5fpin',['RS_PIN',['../lcd_8c.html#ab36f7bcb538b332ae44f0b2b2375b2de',1,'lcd.c']]],
  ['rw_5fpin',['RW_PIN',['../lcd_8c.html#af1976219619b43405b2ebb8a53feb4a0',1,'lcd.c']]]
];
