var searchData=
[
  ['init_2ec',['init.c',['../init_8c.html',1,'']]],
  ['init_2eh',['init.h',['../init_8h.html',1,'']]]
];
